import vista.LoginView;

public class Main {
    public static void main(String[] args) {
        new LoginView().setVisible(true);
    }
}
